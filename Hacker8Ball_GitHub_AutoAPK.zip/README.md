# Hacker 8 Ball — projeto Android

Aplicativo independente de treino/simulação de bilhar. Não modifica nem injeta código no 8 Ball Pool original.

## Compilar APK pelo GitHub

1. Envie todo o conteúdo deste ZIP para a raiz do repositório `Hacker8Ball`, incluindo a pasta oculta `.github`.
2. Faça commit na branch `main` ou `master`.
3. Abra a aba **Actions** do repositório e selecione **Gerar APK Android**.
4. Aguarde a execução terminar com sucesso.
5. Abra a execução concluída e baixe o artefato **Hacker8Ball-debug-apk**.
6. Extraia o ZIP baixado. O arquivo `app-debug.apk` estará dentro dele.

O workflow também pode ser iniciado em Actions → Gerar APK Android → Run workflow.

Este é um APK de depuração para testes, não uma versão de publicação na Play Store.
